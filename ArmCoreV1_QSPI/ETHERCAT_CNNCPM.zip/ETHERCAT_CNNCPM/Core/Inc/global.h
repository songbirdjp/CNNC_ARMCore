#ifndef STM32F401_GLOBAL_H
#define STM32F401_GLOBAL_H

#ifdef __cplusplus
extern "C" {
#endif


extern uint32_t KeyVal;

#endif //STM32F401_GLOBAL_H
