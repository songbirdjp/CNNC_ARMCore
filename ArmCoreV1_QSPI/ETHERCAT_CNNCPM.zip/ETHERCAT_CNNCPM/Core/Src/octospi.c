/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    octospi.c
  * @brief   This file provides code for the configuration
  *          of the OCTOSPI instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "octospi.h"

/* USER CODE BEGIN 0 */
#include "retarget.h"

/* USER CODE END 0 */

OSPI_HandleTypeDef hospi1;

/* OCTOSPI1 init function */
void MX_OCTOSPI1_Init(void)
{

  /* USER CODE BEGIN OCTOSPI1_Init 0 */

  /* USER CODE END OCTOSPI1_Init 0 */

  OSPIM_CfgTypeDef sOspiManagerCfg = {0};

  /* USER CODE BEGIN OCTOSPI1_Init 1 */

  /* USER CODE END OCTOSPI1_Init 1 */
  hospi1.Instance = OCTOSPI1;
  hospi1.Init.FifoThreshold = 1;
  hospi1.Init.DualQuad = HAL_OSPI_DUALQUAD_DISABLE;
  hospi1.Init.MemoryType = HAL_OSPI_MEMTYPE_MICRON;
  hospi1.Init.DeviceSize = 32;
  hospi1.Init.ChipSelectHighTime = 1;
  hospi1.Init.FreeRunningClock = HAL_OSPI_FREERUNCLK_DISABLE;
  hospi1.Init.ClockMode = HAL_OSPI_CLOCK_MODE_0;
  hospi1.Init.WrapSize = HAL_OSPI_WRAP_NOT_SUPPORTED;
  hospi1.Init.ClockPrescaler = 1;
  hospi1.Init.SampleShifting = HAL_OSPI_SAMPLE_SHIFTING_NONE;
  hospi1.Init.DelayHoldQuarterCycle = HAL_OSPI_DHQC_DISABLE;
  hospi1.Init.ChipSelectBoundary = 0;
  hospi1.Init.DelayBlockBypass = HAL_OSPI_DELAY_BLOCK_BYPASSED;
  hospi1.Init.MaxTran = 0;
  hospi1.Init.Refresh = 0;
  if (HAL_OSPI_Init(&hospi1) != HAL_OK)
  {
    Error_Handler();
  }
  sOspiManagerCfg.ClkPort = 1;
  sOspiManagerCfg.NCSPort = 1;
  sOspiManagerCfg.IOLowPort = HAL_OSPIM_IOPORT_1_LOW;
  if (HAL_OSPIM_Config(&hospi1, &sOspiManagerCfg, HAL_OSPI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN OCTOSPI1_Init 2 */

  /* USER CODE END OCTOSPI1_Init 2 */

}

void HAL_OSPI_MspInit(OSPI_HandleTypeDef* ospiHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};
  if(ospiHandle->Instance==OCTOSPI1)
  {
  /* USER CODE BEGIN OCTOSPI1_MspInit 0 */

  /* USER CODE END OCTOSPI1_MspInit 0 */

  /** Initializes the peripherals clock
  */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_OSPI;
    PeriphClkInitStruct.OspiClockSelection = RCC_OSPICLKSOURCE_D1HCLK;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
    {
      Error_Handler();
    }

    /* OCTOSPI1 clock enable */
    __HAL_RCC_OCTOSPIM_CLK_ENABLE();
    __HAL_RCC_OSPI1_CLK_ENABLE();

    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
    /**OCTOSPI1 GPIO Configuration
    PF6     ------> OCTOSPIM_P1_IO3
    PF7     ------> OCTOSPIM_P1_IO2
    PF8     ------> OCTOSPIM_P1_IO0
    PF9     ------> OCTOSPIM_P1_IO1
    PF10     ------> OCTOSPIM_P1_CLK
    PE11     ------> OCTOSPIM_P1_NCS
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF10_OCTOSPIM_P1;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_OCTOSPIM_P1;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_11;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF11_OCTOSPIM_P1;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /* USER CODE BEGIN OCTOSPI1_MspInit 1 */

  /* USER CODE END OCTOSPI1_MspInit 1 */
  }
}

void HAL_OSPI_MspDeInit(OSPI_HandleTypeDef* ospiHandle)
{

  if(ospiHandle->Instance==OCTOSPI1)
  {
  /* USER CODE BEGIN OCTOSPI1_MspDeInit 0 */

  /* USER CODE END OCTOSPI1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_OCTOSPIM_CLK_DISABLE();
    __HAL_RCC_OSPI1_CLK_DISABLE();

    /**OCTOSPI1 GPIO Configuration
    PF6     ------> OCTOSPIM_P1_IO3
    PF7     ------> OCTOSPIM_P1_IO2
    PF8     ------> OCTOSPIM_P1_IO0
    PF9     ------> OCTOSPIM_P1_IO1
    PF10     ------> OCTOSPIM_P1_CLK
    PE11     ------> OCTOSPIM_P1_NCS
    */
    HAL_GPIO_DeInit(GPIOF, GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9
                          |GPIO_PIN_10);

    HAL_GPIO_DeInit(GPIOE, GPIO_PIN_11);

  /* USER CODE BEGIN OCTOSPI1_MspDeInit 1 */

  /* USER CODE END OCTOSPI1_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
void HW_SPI_CS_SetLow(OSPI_HandleTypeDef *hospi)
{
    if (hospi->Instance == OCTOSPI1)
    {
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, GPIO_PIN_RESET);
        //printf("LOWok\r\n");//test ok
    }
}

void HW_SPI_CS_SetHigh(OSPI_HandleTypeDef *hospi)
{
    if (hospi->Instance == OCTOSPI1)
    {
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, GPIO_PIN_SET);
        //printf("HIGHok\r\n");//test ok
    }
}
void LAN9252_Init(void)
{
    OSPI_RegularCmdTypeDef _commandInit_t;
    _commandInit_t.OperationType = HAL_OSPI_OPTYPE_COMMON_CFG;
    _commandInit_t.InstructionMode = HAL_OSPI_INSTRUCTION_1_LINE;
    _commandInit_t.InstructionSize = HAL_OSPI_INSTRUCTION_8_BITS;
    _commandInit_t.Instruction = LAN9252_READ_OPCODE;
    _commandInit_t.AddressMode = HAL_OSPI_ADDRESS_1_LINE;
    _commandInit_t.AddressSize = HAL_OSPI_ADDRESS_24_BITS;
    _commandInit_t.Address = address;
    _commandInit_t.DataMode = HAL_OSPI_DATA_1_LINE;
    _commandInit_t.NbData = 4;
    _commandInit_t.DummyCycles = LAN9252_DUMMY_CYCLES_READ;
}
uint32_t LAN9252_ReadRegister(uint16_t address)
{
    uint32_t rx_data;
    const  uint32_t LAN9252_READ_OPCODE  = 0;
    const  uint32_t LAN9252_DUMMY_CYCLES_READ  = 0xFF;
    OSPI_RegularCmdTypeDef _commandReadOnly_t;

    _commandReadOnly_t.OperationType = HAL_OSPI_OPTYPE_COMMON_CFG;
    _commandReadOnly_t.InstructionMode = HAL_OSPI_INSTRUCTION_1_LINE;
    _commandReadOnly_t.InstructionSize = HAL_OSPI_INSTRUCTION_8_BITS;
    _commandReadOnly_t.Instruction = LAN9252_READ_OPCODE;
    _commandReadOnly_t.AddressMode = HAL_OSPI_ADDRESS_1_LINE;
    _commandReadOnly_t.AddressSize = HAL_OSPI_ADDRESS_24_BITS;
    _commandReadOnly_t.Address = address;
    _commandReadOnly_t.DataMode = HAL_OSPI_DATA_1_LINE;
    _commandReadOnly_t.NbData = 4;
    _commandReadOnly_t.DummyCycles = LAN9252_DUMMY_CYCLES_READ;

    HW_SPI_CS_SetLow(&hospi1);

    //HAL_OSPI_Transmit(&hospi1, command, HAL_OSPI_TIMEOUT_DEFAULT_VALUE);
    if(HAL_OSPI_Command(&hospi1, &_commandReadOnly_t, HAL_OSPI_TIMEOUT_DEFAULT_VALUE) ==HAL_OK)
    {
        if(HAL_OSPI_Receive(&hospi1, (uint8_t *) &rx_data, HAL_OSPI_TIMEOUT_DEFAULT_VALUE) == HAL_OK)
        {
            HW_SPI_CS_SetHigh(&hospi1);
            return rx_data;
        }
        else
        {
            HW_SPI_CS_SetHigh(&hospi1);
            return 0;
        }
    }
    else
    {
        HW_SPI_CS_SetHigh(&hospi1);
        return 0;
    }
}
/* USER CODE END 1 */
