/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "retarget.h"
#include "octospi.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
extern uint32_t KeyVal;

/* USER CODE END Variables */
/* Definitions for Key1Task */
osThreadId_t Key1TaskHandle;
const osThreadAttr_t Key1Task_attributes = {
  .name = "Key1Task",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Key2Task */
osThreadId_t Key2TaskHandle;
const osThreadAttr_t Key2Task_attributes = {
  .name = "Key2Task",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for QspiFunction */
osThreadId_t QspiFunctionHandle;
const osThreadAttr_t QspiFunction_attributes = {
  .name = "QspiFunction",
  .stack_size = 1024 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void Key1Function(void *argument);
void Key2Function(void *argument);
void LAN9252InitByQSPI(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
    /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
    /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
    /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
    /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Key1Task */
  Key1TaskHandle = osThreadNew(Key1Function, NULL, &Key1Task_attributes);

  /* creation of Key2Task */
  Key2TaskHandle = osThreadNew(Key2Function, NULL, &Key2Task_attributes);

  /* creation of QspiFunction */
  QspiFunctionHandle = osThreadNew(LAN9252InitByQSPI, NULL, &QspiFunction_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
    /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
    /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_Key1Function */
/**
  * @brief  Function implementing the Key1Task thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_Key1Function */
void Key1Function(void *argument)
{
  /* USER CODE BEGIN Key1Function */
    /* Infinite loop */
    for (;;)
    {
        uint16_t _keyState = KeyVal & 0x01;
        if ((KeyVal >> 16) == 0x1000)
        {
            if (_keyState == 1)
            {
                HAL_GPIO_WritePin(GPIOG, GPIO_PIN_9, GPIO_PIN_SET);
                osDelay(100);
                HAL_GPIO_WritePin(GPIOG, GPIO_PIN_9, GPIO_PIN_RESET);
                KeyVal = 0;
            }
            //osDelay(1);
        }
  /* USER CODE END Key1Function */
}

/* USER CODE BEGIN Header_Key2Function */
/**
* @brief Function implementing the Key2Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Key2Function */
void Key2Function(void *argument)
{
  /* USER CODE BEGIN Key2Function */
    /* Infinite loop */
    for (;;)
    {
        uint16_t _keyState = KeyVal & 0x01;
        if ((KeyVal >> 16) == 0x2000)
        {
            if (_keyState == 1)
            {
                HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, GPIO_PIN_SET);
                osDelay(100);
                HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, GPIO_PIN_RESET);
                KeyVal = 0;
            }
            //osDelay(1);
        }
    }
  /* USER CODE END Key2Function */
}

/* USER CODE BEGIN Header_LAN9252InitByQSPI */
/**
* @brief Function implementing the QspiFunction thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_LAN9252InitByQSPI */
void LAN9252InitByQSPI(void *argument)
{
  /* USER CODE BEGIN LAN9252InitByQSPI */
    /* Infinite loop */
    for (;;)
    {
        LAN9252_ReadRegister(0x050);
        osDelay(100);
    }
  /* USER CODE END LAN9252InitByQSPI */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

